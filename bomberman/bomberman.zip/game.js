var array = [[2, 2, 2, 2, 2, 2],
			[2, 0, 1, 1, 1, 2],
			[2, 0, 0, 1, 0, 2],
			[2, 0, 1 ,1, 0, 2],
			[2, 0, 0, 0, 0, 2],
			[2, 0, 1, 1, 1, 2],
			[2, 0, 0, 1, 0, 2],
			[2, 2, 2, 2, 2, 2]];

function createMap(array) {
	for (var x = 0; x < array.length; x++) {
		for (var y = 0; y < array[x].length; y++) {
			get = document.getElementById("game");
			create = document.createElement("div");
			var obj = get.appendChild(create);
			switch (array[x][y]) {
				case 0:
				obj.classList.add("block00");
				break;
				case 1:
				obj.classList.add("block11");
				break;
				case 2:
				obj.classList.add("block22");
				break;
			}
		}
var obj2 = get.appendChild(document.createElement("div")).className += "clearfix";
	}
	asd
}

createMap(array);

// function show_image(src, width, height) {
//     var img = document.createElement("img");
//     img.src = src;
//     img.width = width;
//     img.height = height;

//     // This next line will just add it to the <body> tag
//     var get2 = document.getElementsByClassName("block00");
//     show = get2.appendChild(img);
// }

function show_image(src, width, height) {
    var img = document.createElement("img");
    img.src = src;
    img.width = width;
    img.height = height;

    // This next line will just add it to the <body> tag
    document.body.appendChild(img);
}

	if(document.getElementsByClassName("block00")) {
		show_image("player.png", "35", "35");
	}
